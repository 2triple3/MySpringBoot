package com.louis.kitty.admin.constants;

/**
 * 常量管理
 * @author Louis
 * @date Oct 29, 2018
 */ 
public interface SysConstants {

	/**
	 * 系统管理员用户名
	 */
	String ADMIN = "admin";
	
}
